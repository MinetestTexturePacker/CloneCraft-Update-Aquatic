lavatemple = {}
local MODPATH = minetest.get_modpath("lavatemple")
dofile(MODPATH.."/nodes.lua")
dofile(MODPATH.."/items.lua")
dofile(MODPATH.."/mapgen.lua")
dofile(MODPATH.."/dagger.lua")

