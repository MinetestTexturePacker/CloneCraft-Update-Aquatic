rain 0.2.0 by paramat
For latest stable Minetest back to 0.4.8
Depends default
Licenses: code WTFPL, textures CC BY-SA
